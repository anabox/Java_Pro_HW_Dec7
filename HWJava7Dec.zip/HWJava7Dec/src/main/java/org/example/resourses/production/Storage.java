package org.example.resourses.production;

import java.util.HashSet;
import java.util.Set;

public class Storage {
    private final Set<Resource> storage;
    private static final int STORAGE_SIZE = 50;

    public Storage() {this.storage = new HashSet<>();}
    public synchronized void produce(Resource resource, int producerId) throws InterruptedException {
        while (storage.size() >= STORAGE_SIZE) {
            System.out.printf("Время: %s, производитель с id %d ждёт, по сколько склад заполнен.%n",System.currentTimeMillis(),producerId);
            wait();
        }

        storage.add(resource);
        System.out.printf("Время: %s, производитель с id %d производит ресурс с id %d. Всего ресурсов на складе: %d.%n",System.currentTimeMillis(),producerId,resource.getId(),storage.size());
        notifyAll();
    }

    public synchronized void consume(int consumerId) throws InterruptedException {
        while (storage.isEmpty()) {
            System.out.printf("Время: %s,потребитель с id %d ждёт, по сколько склад пуст.%n",System.currentTimeMillis(),consumerId);
            wait();
        }

        Resource resource = storage.stream().findFirst().orElseThrow();
        storage.remove(resource);
        System.out.printf("Время: %s, потребитель с id %d забирает ресурс с id %d. Всего ресурсов на складе: %d.%n",System.currentTimeMillis(),consumerId,resource.getId(),storage.size());
        notifyAll();
    }
}
