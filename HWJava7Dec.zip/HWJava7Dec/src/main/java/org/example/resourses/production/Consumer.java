package org.example.resourses.production;

public class Consumer implements Runnable {
    private Storage storage;
    private int consumerId;
    private int consumerTime;

    public Consumer(Storage storage, int consumerId, int consumerTime) {
        this.storage = storage;
        this.consumerId = consumerId;
        this.consumerTime = consumerTime;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(consumerTime);
                storage.consume(consumerId);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
