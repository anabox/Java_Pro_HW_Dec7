package org.example.resourses.production;

public class Producer implements Runnable {
    private Storage storage;
    private int producerId;
    private int producerTime;

    public Producer(Storage storage, int producerId, int producerTime) {
        this.storage = storage;
        this.producerId = producerId;
        this.producerTime = producerTime;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(producerTime);
                Resource resource = new Resource();
                storage.produce(resource, producerId);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

