package org.example.resourses.production;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
//Многопоточное производство. Написать реализовать схему производства - потребления ресурсов.
//Есть producerCount потоков, производящих ресурс. Каждый производитель производит 1 единицу ресурса в producerTime времени.
//Производители помещают ресурсы на склад, размера storageSize. Больше, чем storageSize ресурсов, на складе хранить нельзя.
//Есть consumerCount потоков, потребляющих ресурсы. Каждый потребитель забирает со склада 1 единицу ресурса в consumerTime времени.
//Если склад пустой, потоки-потребители ждут. Как только ресурсы появились, потоки сразу же начинают их потреблять.
//Если склад переполнен, потоки-производители ждут, пока потребители не освободят место.
//producerCount, consumerCount, producerTime, consumerTime, storageSize – конфигурируются в .properties-файле
//Ресурс имеет уникальный идентификатор для отслеживания
//Производители и потребители так же имеют идентификаторы (порядковые номера)
//
//Писать в лог (консоль) сообщение: время, номер и тип потока, id-ресурса, событие (произведен или потреблен).
//Писать в лог сообщение: количество ресурсов на складе при доставке/потреблении на склад.
//Писать в лог сообщение: время, номер и тип потока, событие (когда потоки переходят в режим ожидания или возобновляют работу).
//В задаче нельзя использовать java.util.concurrency

public class Main {
    public static void main(String[] args) {
        Properties properties = new Properties();
        try (FileInputStream input = new FileInputStream("configuration.properties")) {
            properties.load(input);

            int producerCount = Integer.parseInt(properties.getProperty("producerCount"));
            int consumerCount = Integer.parseInt(properties.getProperty("consumerCount"));
            int producerTime = Integer.parseInt(properties.getProperty("producerTime"));
            int consumerTime = Integer.parseInt(properties.getProperty("consumerTime"));

            Storage storage = new Storage();

            for (int i = 1; i <= producerCount; i++) {
                new Thread(new Producer(storage, i, producerTime)).start();
            }

            for (int i = 1; i <= consumerCount; i++) {
                new Thread(new Consumer(storage, i, consumerTime)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

