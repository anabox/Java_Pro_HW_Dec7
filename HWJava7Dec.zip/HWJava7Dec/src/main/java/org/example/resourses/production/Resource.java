package org.example.resourses.production;

public class Resource {
    private static int counter = 1;
    private final int id;

    public Resource() {
        this.id = counter++;
    }

    public int getId() {
        return id;
    }


}
